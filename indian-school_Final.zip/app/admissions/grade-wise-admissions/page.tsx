import Link from "next/link"

export default function GradeWiseAdmissionsPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-8 text-primary">Grade-wise Admissions</h1>
      <div className="grid gap-8">
        <section>
          <h2 className="text-2xl font-bold mb-4">Admission Process</h2>
          <ol className="list-decimal list-inside space-y-2">
            <li>Submit online application form</li>
            <li>Entrance test (for grades 2 and above)</li>
            <li>Document verification</li>
            <li>Principal's interview</li>
            <li>Admission offer and fee payment</li>
          </ol>
        </section>
        <section>
          <h2 className="text-2xl font-bold mb-4">Available Grades</h2>
          <p className="mb-4">We offer admissions to the following grades, subject to seat availability:</p>
          <ul className="list-disc list-inside space-y-2">
            <li>Primary School (Grades 1-5)</li>
            <li>Middle School (Grades 6-8)</li>
            <li>High School (Grades 9-10)</li>
            <li>Senior Secondary (Grades 11-12)</li>
          </ul>
        </section>
        <section>
          <h2 className="text-2xl font-bold mb-4">Required Documents</h2>
          <ul className="list-disc list-inside space-y-2">
            <li>Birth certificate</li>
            <li>Previous school records</li>
            <li>Transfer certificate (if applicable)</li>
            <li>Passport-size photographs</li>
            <li>Address proof</li>
          </ul>
        </section>
      </div>
      <div className="mt-8">
        <Link href="/admissions" className="text-primary hover:underline">
          &larr; Back to Admissions
        </Link>
      </div>
    </div>
  )
}

