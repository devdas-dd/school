import Link from "next/link"
import { FileText, Users, Calendar } from "lucide-react"

export default function AdmissionsPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-8 text-primary">Admissions</h1>
      <p className="mb-8 text-lg">
        Welcome to the Indian School admissions page. We are excited to welcome new students to our community of
        learners.
      </p>
      <div className="grid gap-8 md:grid-cols-3">
        <div className="bg-white rounded-lg shadow-md p-6">
          <FileText className="h-12 w-12 text-primary mb-4" />
          <h2 className="text-xl font-bold mb-2">Admission Process</h2>
          <p className="text-gray-600 mb-4">Learn about our step-by-step admission process and required documents.</p>
          <Link href="/admissions/process" className="text-primary hover:underline">
            View Details
          </Link>
        </div>
        <div className="bg-white rounded-lg shadow-md p-6">
          <Users className="h-12 w-12 text-primary mb-4" />
          <h2 className="text-xl font-bold mb-2">Preschool Admissions</h2>
          <p className="text-gray-600 mb-4">Information about admissions for our youngest learners.</p>
          <Link href="/admissions/pre-school" className="text-primary hover:underline">
            Learn More
          </Link>
        </div>
        <div className="bg-white rounded-lg shadow-md p-6">
          <Calendar className="h-12 w-12 text-primary mb-4" />
          <h2 className="text-xl font-bold mb-2">Grade-wise Admissions</h2>
          <p className="text-gray-600 mb-4">Details on admissions for different grades and academic years.</p>
          <Link href="/admissions/grade-wise-admissions" className="text-primary hover:underline">
            Explore Options
          </Link>
        </div>
      </div>
    </div>
  )
}

