import Link from "next/link"

export default function PreSchoolAdmissionsPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-8 text-primary">Preschool Admissions</h1>
      <div className="grid gap-8 md:grid-cols-2">
        <section>
          <h2 className="text-2xl font-bold mb-4">Admission Process</h2>
          <ol className="list-decimal list-inside space-y-2">
            <li>Submit online application form</li>
            <li>Attend parent interaction session</li>
            <li>Student observation (play-based assessment)</li>
            <li>Document verification</li>
            <li>Admission offer and fee payment</li>
          </ol>
        </section>
        <section>
          <h2 className="text-2xl font-bold mb-4">Age Criteria</h2>
          <ul className="list-disc list-inside space-y-2">
            <li>Nursery: 3+ years as of 31st March of the admission year</li>
            <li>Lower KG: 4+ years as of 31st March of the admission year</li>
            <li>Upper KG: 5+ years as of 31st March of the admission year</li>
          </ul>
        </section>
      </div>
      <div className="mt-8">
        <Link href="/admissions" className="text-primary hover:underline">
          &larr; Back to Admissions
        </Link>
      </div>
    </div>
  )
}

