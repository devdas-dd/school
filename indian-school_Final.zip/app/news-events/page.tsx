import Image from "next/image"
import Link from "next/link"
import { Calendar, Clock, ArrowRight } from "lucide-react"

// Sample news data
const newsItems = [
  {
    id: 1,
    title: "Annual Sports Day 2025",
    date: "March 15, 2025",
    image: "/placeholder.svg?height=200&width=300",
    excerpt:
      "Join us for a day of athletic competitions and team sports. Students from all grades will participate in various events.",
    slug: "annual-sports-day-2025",
  },
  {
    id: 2,
    title: "Science Exhibition",
    date: "April 5, 2025",
    image: "/placeholder.svg?height=200&width=300",
    excerpt:
      "Students will showcase their innovative science projects and experiments. Parents and community members are invited to attend.",
    slug: "science-exhibition-2025",
  },
  {
    id: 3,
    title: "Parent-Teacher Meeting",
    date: "April 20, 2025",
    image: "/placeholder.svg?height=200&width=300",
    excerpt: "An opportunity for parents to discuss their child's progress with teachers and address any concerns.",
    slug: "parent-teacher-meeting-april-2025",
  },
  {
    id: 4,
    title: "Cultural Fest 'Sargam'",
    date: "May 10, 2025",
    image: "/placeholder.svg?height=200&width=300",
    excerpt:
      "Our annual cultural festival featuring music, dance, drama, and art performances by students of all grades.",
    slug: "cultural-fest-sargam-2025",
  },
  {
    id: 5,
    title: "International Yoga Day Celebration",
    date: "June 21, 2025",
    image: "/placeholder.svg?height=200&width=300",
    excerpt:
      "Join us as we celebrate International Yoga Day with special yoga sessions and wellness workshops for students and parents.",
    slug: "international-yoga-day-2025",
  },
  {
    id: 6,
    title: "Independence Day Celebration",
    date: "August 15, 2025",
    image: "/placeholder.svg?height=200&width=300",
    excerpt: "A special assembly and cultural program to commemorate India's Independence Day.",
    slug: "independence-day-2025",
  },
]

// Sample upcoming events
const upcomingEvents = [
  {
    id: 1,
    title: "Annual Sports Day",
    date: "March 15, 2025",
    time: "9:00 AM - 4:00 PM",
    venue: "School Sports Ground",
  },
  {
    id: 2,
    title: "Science Exhibition",
    date: "April 5, 2025",
    time: "10:00 AM - 3:00 PM",
    venue: "School Auditorium",
  },
  {
    id: 3,
    title: "Parent-Teacher Meeting",
    date: "April 20, 2025",
    time: "9:00 AM - 12:00 PM",
    venue: "Respective Classrooms",
  },
  {
    id: 4,
    title: "Cultural Fest 'Sargam'",
    date: "May 10, 2025",
    time: "5:00 PM - 8:00 PM",
    venue: "School Auditorium",
  },
]

export default function NewsEventsPage() {
  return (
    <div>
      {/* Banner */}
      <div className="bg-primary py-16 md:py-24">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground mb-4">News & Events</h1>
          <p className="text-primary-foreground/80 max-w-2xl mx-auto">
            Stay updated with the latest news and upcoming events at Indian School.
          </p>
        </div>
      </div>

      {/* Latest News */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-primary">Latest News</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {newsItems.map((item) => (
              <div key={item.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative h-48">
                  <Image src={item.image || "/placeholder.svg"} alt={item.title} fill className="object-cover" />
                </div>
                <div className="p-6">
                  <div className="flex items-center text-primary mb-2">
                    <Calendar className="h-4 w-4 mr-1" />
                    <span className="text-sm">{item.date}</span>
                  </div>
                  <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                  <p className="text-gray-600 mb-4">{item.excerpt}</p>
                  <Link
                    href={`/news-events/${item.slug}`}
                    className="inline-flex items-center text-primary hover:text-primary/80 font-medium"
                  >
                    Read More <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Upcoming Events */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-primary">Upcoming Events</h2>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-bold mb-6 border-b pb-4">Event Calendar</h3>

              <div className="space-y-6">
                {upcomingEvents.map((event) => (
                  <div key={event.id} className="flex border-b pb-4 last:border-0 last:pb-0">
                    <div className="bg-primary/10 text-primary rounded-lg p-3 text-center min-w-[80px] mr-4">
                      <div className="text-sm font-medium">{event.date.split(" ")[0]}</div>
                      <div className="text-lg font-bold">{event.date.split(" ")[1].replace(",", "")}</div>
                    </div>
                    <div>
                      <h4 className="font-bold">{event.title}</h4>
                      <div className="text-sm text-gray-600 mt-1 flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        {event.time}
                      </div>
                      <div className="text-sm text-gray-600 mt-1">Venue: {event.venue}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-bold mb-6">Annual Events</h3>

              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="bg-primary/10 p-2 rounded-full mr-3 text-primary">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-bold">Annual Sports Day</h4>
                    <p className="text-gray-600 text-sm">
                      Held every year in March, this event showcases the sporting talents of our students through
                      various athletic competitions and team sports.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-primary/10 p-2 rounded-full mr-3 text-primary">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-bold">Science Exhibition</h4>
                    <p className="text-gray-600 text-sm">
                      An annual event where students showcase their scientific knowledge and creativity through
                      innovative projects and experiments.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-primary/10 p-2 rounded-full mr-3 text-primary">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-bold">Cultural Fest 'Sargam'</h4>
                    <p className="text-gray-600 text-sm">
                      Our annual cultural festival featuring music, dance, drama, and art performances by students of
                      all grades.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-primary/10 p-2 rounded-full mr-3 text-primary">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-bold">Annual Day</h4>
                    <p className="text-gray-600 text-sm">
                      A grand celebration at the end of the academic year to recognize and reward the achievements of
                      our students.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Subscription */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="bg-primary/10 rounded-lg p-8 md:p-12">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-2xl font-bold mb-4 text-primary">Subscribe to Our Newsletter</h2>
              <p className="text-gray-600 mb-6">
                Stay updated with the latest news, events, and announcements from Indian School.
              </p>

              <form className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
                <input
                  type="email"
                  placeholder="Your Email Address"
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  required
                />
                <button
                  type="submit"
                  className="bg-primary text-white px-6 py-2 rounded-md hover:bg-primary/90 transition-colors"
                >
                  Subscribe
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

