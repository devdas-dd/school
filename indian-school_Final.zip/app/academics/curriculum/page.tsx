import { Book, Beaker, Globe, Calculator, Music, Dumbbell } from "lucide-react"

const subjects = [
  {
    name: "English",
    icon: Book,
    description: "Develop strong communication skills through literature, writing, and language studies.",
  },
  {
    name: "Science",
    icon: Beaker,
    description: "Explore physics, chemistry, and biology with hands-on experiments and critical thinking.",
  },
  {
    name: "Social Studies",
    icon: Globe,
    description: "Gain a deeper understanding of history, geography, and current global issues.",
  },
  {
    name: "Mathematics",
    icon: Calculator,
    description: "Build problem-solving skills through algebra, geometry, and advanced math concepts.",
  },
  {
    name: "Arts",
    icon: Music,
    description: "Express creativity through visual arts, music, dance, and drama.",
  },
  {
    name: "Physical Education",
    icon: Dumbbell,
    description: "Promote physical fitness, teamwork, and healthy lifestyle choices.",
  },
]

export default function CurriculumPage() {
  return (
    <div>
      {/* Banner */}
      <div className="bg-primary py-16 md:py-24">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground mb-4">Our Curriculum</h1>
          <p className="text-primary-foreground/80 max-w-2xl mx-auto">
            Discover our comprehensive CBSE curriculum designed to nurture well-rounded individuals prepared for future
            challenges.
          </p>
        </div>
      </div>

      {/* Curriculum Overview */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold mb-6 text-primary">Curriculum Overview</h2>
            <p className="text-gray-600 mb-4">
              At Indian School, we follow the Central Board of Secondary Education (CBSE) curriculum, which is known for
              its comprehensive and balanced approach to education. Our curriculum is designed to:
            </p>
            <ul className="list-disc list-inside text-gray-600 mb-4 space-y-2">
              <li>Promote conceptual understanding and critical thinking</li>
              <li>Encourage creativity and innovation</li>
              <li>Develop strong communication and collaboration skills</li>
              <li>Foster a global perspective and cultural awareness</li>
              <li>Prepare students for competitive exams and higher education</li>
            </ul>
            <p className="text-gray-600">
              We supplement the CBSE curriculum with additional resources, project-based learning, and real-world
              applications to ensure our students receive a well-rounded education.
            </p>
          </div>
        </div>
      </section>

      {/* Key Subjects */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-primary text-center">Key Subjects</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {subjects.map((subject, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-center mb-4">
                  <subject.icon className="h-8 w-8 text-primary mr-3" />
                  <h3 className="text-xl font-bold">{subject.name}</h3>
                </div>
                <p className="text-gray-600">{subject.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Teaching Methodology */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold mb-6 text-primary">Teaching Methodology</h2>
            <p className="text-gray-600 mb-4">
              Our teaching methodology is designed to engage students actively in the learning process and cater to
              diverse learning styles. We employ a variety of techniques, including:
            </p>
            <ul className="list-disc list-inside text-gray-600 mb-4 space-y-2">
              <li>Interactive classroom discussions</li>
              <li>Hands-on experiments and practical applications</li>
              <li>Project-based learning and group activities</li>
              <li>Technology integration and digital resources</li>
              <li>Field trips and guest lectures</li>
              <li>Personalized attention and differentiated instruction</li>
            </ul>
            <p className="text-gray-600">
              This multi-faceted approach ensures that our students not only grasp the subject matter but also develop
              critical thinking, problem-solving, and collaboration skills essential for success in the 21st century.
            </p>
          </div>
        </div>
      </section>

      {/* Assessment and Evaluation */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold mb-6 text-primary">Assessment and Evaluation</h2>
            <p className="text-gray-600 mb-4">
              We believe in continuous and comprehensive evaluation to monitor student progress and provide timely
              feedback. Our assessment methods include:
            </p>
            <ul className="list-disc list-inside text-gray-600 mb-4 space-y-2">
              <li>Regular formative assessments</li>
              <li>Summative exams aligned with CBSE guidelines</li>
              <li>Project evaluations and practical assessments</li>
              <li>Continuous classroom observations</li>
              <li>Parent-teacher meetings to discuss student progress</li>
            </ul>
            <p className="text-gray-600">
              This holistic approach to assessment helps us identify areas for improvement and celebrate student
              achievements, fostering a positive learning environment.
            </p>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6 text-primary">Experience Our Curriculum in Action</h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Want to see how our curriculum comes to life in the classroom? Schedule a visit to observe our engaging
            lessons and interact with our faculty.
          </p>
          <a
            href="/contact"
            className="inline-flex items-center bg-primary text-white px-6 py-3 rounded-md hover:bg-primary/90 transition-colors"
          >
            Schedule a Visit
          </a>
        </div>
      </section>
    </div>
  )
}

