import Image from "next/image"
import Link from "next/link"
import { BookOpen, Users, FileText, Calendar, ArrowRight } from "lucide-react"

export default function AcademicsPage() {
  return (
    <div>
      {/* Banner */}
      <div className="relative h-[300px] md:h-[400px]">
        <Image src="/placeholder.svg?height=400&width=1200" alt="Academics" fill className="object-cover" priority />
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white">Academics</h1>
        </div>
      </div>

      {/* Introduction */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6 text-primary">Academic Excellence</h2>
            <p className="text-gray-600 mb-4">
              At Indian School, we are committed to providing a comprehensive and balanced education that nurtures
              intellectual curiosity, critical thinking, and a love for learning. Our academic program is designed to
              challenge students while providing the support they need to succeed.
            </p>
            <p className="text-gray-600">
              We follow the Central Board of Secondary Education (CBSE) curriculum, which is enhanced with additional
              resources and teaching methodologies to ensure a well-rounded education.
            </p>
          </div>
        </div>
      </section>

      {/* Academic Features */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Link
              href="/academics/curriculum"
              className="bg-white rounded-lg shadow-md p-6 transition-all hover:shadow-lg"
            >
              <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary mb-4">
                <BookOpen className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-2">Curriculum</h3>
              <p className="text-gray-600 mb-4">
                Our CBSE curriculum is designed to develop both academic knowledge and essential life skills.
              </p>
              <div className="inline-flex items-center text-primary hover:text-primary/80 font-medium">
                Learn More <ArrowRight className="ml-1 h-4 w-4" />
              </div>
            </Link>

            <Link
              href="/academics/faculty"
              className="bg-white rounded-lg shadow-md p-6 transition-all hover:shadow-lg"
            >
              <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary mb-4">
                <Users className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-2">Faculty</h3>
              <p className="text-gray-600 mb-4">
                Our experienced and dedicated teachers are committed to providing the best education.
              </p>
              <div className="inline-flex items-center text-primary hover:text-primary/80 font-medium">
                Learn More <ArrowRight className="ml-1 h-4 w-4" />
              </div>
            </Link>

            <Link
              href="/academics/examinations"
              className="bg-white rounded-lg shadow-md p-6 transition-all hover:shadow-lg"
            >
              <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary mb-4">
                <FileText className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-2">Examinations</h3>
              <p className="text-gray-600 mb-4">
                Our assessment methods are designed to evaluate understanding and application of concepts.
              </p>
              <div className="inline-flex items-center text-primary hover:text-primary/80 font-medium">
                Learn More <ArrowRight className="ml-1 h-4 w-4" />
              </div>
            </Link>

            <Link
              href="/academics/year-planner"
              className="bg-white rounded-lg shadow-md p-6 transition-all hover:shadow-lg"
            >
              <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary mb-4">
                <Calendar className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-2">Year Planner</h3>
              <p className="text-gray-600 mb-4">
                Our academic calendar provides a schedule of all academic activities throughout the year.
              </p>
              <div className="inline-flex items-center text-primary hover:text-primary/80 font-medium">
                Learn More <ArrowRight className="ml-1 h-4 w-4" />
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* Academic Approach */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative h-[400px] rounded-lg overflow-hidden">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Academic Approach"
                fill
                className="object-cover"
              />
            </div>
            <div>
              <h2 className="text-3xl font-bold mb-6 text-primary">Our Academic Approach</h2>
              <p className="text-gray-600 mb-4">
                At Indian School, we believe in a student-centered approach to education. Our teaching methodologies are
                designed to engage students actively in the learning process, encouraging them to think critically,
                solve problems, and apply their knowledge in real-world contexts.
              </p>
              <p className="text-gray-600 mb-4">
                We emphasize conceptual understanding over rote memorization, helping students develop a deep and
                lasting understanding of the subjects they study. Our teachers use a variety of teaching strategies,
                including interactive discussions, hands-on activities, project-based learning, and technology
                integration, to cater to different learning styles and abilities.
              </p>
              <p className="text-gray-600">
                Regular assessments, both formative and summative, help us track student progress and provide timely
                feedback and support. We also encourage students to reflect on their learning and set goals for
                improvement.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Academic Levels */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-primary text-center">Academic Levels</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-bold mb-4 text-primary">Primary School (Classes I-V)</h3>
              <p className="text-gray-600 mb-4">
                In the primary years, we focus on building a strong foundation in core subjects while nurturing
                curiosity and creativity. Our child-centered approach ensures that learning is engaging and enjoyable.
              </p>
              <ul className="list-disc list-inside text-gray-600 space-y-2">
                <li>Focus on literacy and numeracy skills</li>
                <li>Introduction to science and social studies</li>
                <li>Art, music, and physical education</li>
                <li>Value education and life skills</li>
              </ul>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-bold mb-4 text-primary">Middle School (Classes VI-VIII)</h3>
              <p className="text-gray-600 mb-4">
                The middle school program builds on the foundation laid in primary school, introducing more complex
                concepts and developing critical thinking and analytical skills.
              </p>
              <ul className="list-disc list-inside text-gray-600 space-y-2">
                <li>In-depth study of languages, mathematics, and sciences</li>
                <li>Introduction to specialized subjects</li>
                <li>Project-based learning and research skills</li>
                <li>Leadership and teamwork development</li>
              </ul>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-bold mb-4 text-primary">Secondary School (Classes IX-XII)</h3>
              <p className="text-gray-600 mb-4">
                The secondary school program prepares students for board examinations and higher education, focusing on
                academic excellence while continuing to develop character and life skills.
              </p>
              <ul className="list-disc list-inside text-gray-600 space-y-2">
                <li>Comprehensive preparation for CBSE board examinations</li>
                <li>Choice of streams: Science, Commerce, and Humanities</li>
                <li>Career guidance and counseling</li>
                <li>Emphasis on practical applications and real-world connections</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Academic Achievements */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-primary text-center">Academic Achievements</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-bold mb-4">Board Examination Results</h3>
              <p className="text-gray-600 mb-4">
                Our students consistently achieve excellent results in CBSE board examinations, with many securing top
                ranks at the national level.
              </p>
              <div className="space-y-4">
                <div>
                  <h4 className="font-bold">Class XII (2024)</h4>
                  <ul className="list-disc list-inside text-gray-600">
                    <li>100% pass rate</li>
                    <li>85% students scored above 80%</li>
                    <li>School topper: 98.6%</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-bold">Class X (2024)</h4>
                  <ul className="list-disc list-inside text-gray-600">
                    <li>100% pass rate</li>
                    <li>90% students scored above 80%</li>
                    <li>School topper: 99.2%</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-bold mb-4">Competitive Examinations</h3>
              <p className="text-gray-600 mb-4">
                Our students have excelled in various competitive examinations and olympiads at the national and
                international levels.
              </p>
              <ul className="list-disc list-inside text-gray-600 space-y-2">
                <li>National Talent Search Examination (NTSE)</li>
                <li>Science, Mathematics, and Informatics Olympiads</li>
                <li>KVPY and other scholarship examinations</li>
                <li>JEE (Main and Advanced) and NEET</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

