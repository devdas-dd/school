import Image from "next/image"
import { Mail } from "lucide-react"

const facultyMembers = [
  {
    name: "Dr. Rajesh Kumar",
    position: "Head of Science Department",
    image: "/placeholder.svg?height=300&width=300",
    bio: "Dr. Kumar has over 20 years of experience in teaching Physics and has published numerous research papers in renowned scientific journals.",
    email: "rajesh.kumar@indianschool.edu",
  },
  {
    name: "Mrs. Priya Sharma",
    position: "English Literature Professor",
    image: "/placeholder.svg?height=300&width=300",
    bio: "Mrs. Sharma is a passionate educator with a flair for bringing classic and contemporary literature to life in the classroom.",
    email: "priya.sharma@indianschool.edu",
  },
  {
    name: "Mr. Amit Patel",
    position: "Mathematics Instructor",
    image: "/placeholder.svg?height=300&width=300",
    bio: "Mr. Patel specializes in making complex mathematical concepts accessible and engaging for students of all levels.",
    email: "amit.patel@indianschool.edu",
  },
  {
    name: "Dr. Sunita Reddy",
    position: "Biology Teacher",
    image: "/placeholder.svg?height=300&width=300",
    bio: "With a Ph.D. in Molecular Biology, Dr. Reddy brings cutting-edge scientific knowledge to her classes, inspiring the next generation of scientists.",
    email: "sunita.reddy@indianschool.edu",
  },
  {
    name: "Mr. Vikram Singh",
    position: "Physical Education Instructor",
    image: "/placeholder.svg?height=300&width=300",
    bio: "A former national-level athlete, Mr. Singh is dedicated to promoting physical fitness and sportsmanship among students.",
    email: "vikram.singh@indianschool.edu",
  },
  {
    name: "Ms. Ananya Gupta",
    position: "Computer Science Teacher",
    image: "/placeholder.svg?height=300&width=300",
    bio: "Ms. Gupta is at the forefront of technology education, teaching students programming, web development, and artificial intelligence.",
    email: "ananya.gupta@indianschool.edu",
  },
]

export default function FacultyPage() {
  return (
    <div>
      {/* Banner */}
      <div className="bg-primary py-16 md:py-24">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground mb-4">Our Faculty</h1>
          <p className="text-primary-foreground/80 max-w-2xl mx-auto">
            Meet the dedicated educators who inspire and guide our students towards academic excellence and personal
            growth.
          </p>
        </div>
      </div>

      {/* Faculty Profiles */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {facultyMembers.map((faculty, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative h-64">
                  <Image src={faculty.image || "/placeholder.svg"} alt={faculty.name} fill className="object-cover" />
                </div>
                <div className="p-6">
                  <h2 className="text-xl font-bold mb-2">{faculty.name}</h2>
                  <p className="text-primary font-medium mb-4">{faculty.position}</p>
                  <p className="text-gray-600 mb-4">{faculty.bio}</p>
                  <div className="flex items-center text-primary">
                    <Mail className="h-5 w-5 mr-2" />
                    <a href={`mailto:${faculty.email}`} className="hover:underline">
                      {faculty.email}
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Join Our Team */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6 text-primary">Join Our Team</h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            We are always looking for passionate educators to join our faculty. If you're dedicated to shaping young
            minds and fostering a love for learning, we'd love to hear from you.
          </p>
          <a
            href="/careers"
            className="inline-flex items-center bg-primary text-white px-6 py-3 rounded-md hover:bg-primary/90 transition-colors"
          >
            View Career Opportunities
          </a>
        </div>
      </section>
    </div>
  )
}

