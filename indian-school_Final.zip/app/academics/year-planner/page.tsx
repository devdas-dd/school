import Link from "next/link"

export default function YearPlannerPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-8 text-primary">Academic Year Planner</h1>
      <div className="grid gap-8">
        <section>
          <h2 className="text-2xl font-bold mb-4">2024-2025 Academic Year</h2>
          <ul className="list-disc list-inside">
            <li>First Term: April 1, 2024 - September 30, 2024</li>
            <li>Second Term: October 1, 2024 - March 31, 2025</li>
            <li>Summer Vacation: May 15, 2024 - June 30, 2024</li>
            <li>Winter Break: December 24, 2024 - January 1, 2025</li>
          </ul>
        </section>
        <section>
          <h2 className="text-2xl font-bold mb-4">Key Dates</h2>
          <ul className="list-disc list-inside">
            <li>First Term Exams: August 15-30, 2024</li>
            <li>Half-Yearly Exams: December 1-15, 2024</li>
            <li>Annual Day: February 15, 2025</li>
            <li>Annual Exams: March 1-15, 2025</li>
          </ul>
        </section>
        <div className="mt-8">
          <Link href="/academics" className="text-primary hover:underline">
            &larr; Back to Academics
          </Link>
        </div>
      </div>
    </div>
  )
}

