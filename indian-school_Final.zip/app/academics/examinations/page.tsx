import Link from "next/link"

export default function ExaminationsPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-8 text-primary">Examinations</h1>
      <div className="grid gap-8">
        <section>
          <h2 className="text-2xl font-bold mb-4">Examination Schedule</h2>
          <p className="mb-4">
            Our examination schedule is designed to assess students' progress throughout the academic year.
          </p>
          <ul className="list-disc list-inside">
            <li>First Term Exams: August-September</li>
            <li>Half-Yearly Exams: December</li>
            <li>Annual Exams: March-April</li>
          </ul>
        </section>
        <section>
          <h2 className="text-2xl font-bold mb-4">Year Planner</h2>
          <p className="mb-4">
            Our comprehensive year planner outlines all academic activities, including examinations, throughout the
            school year.
          </p>
          <Link href="/academics/year-planner" className="text-primary hover:underline">
            View Full Year Planner
          </Link>
        </section>
      </div>
    </div>
  )
}

