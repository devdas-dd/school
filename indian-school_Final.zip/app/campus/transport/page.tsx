import { Bus, Clock, MapPin, Phone } from "lucide-react"

export default function TransportPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-8 text-primary">School Transport</h1>
      <div className="grid gap-8 md:grid-cols-2">
        <section>
          <h2 className="text-2xl font-bold mb-4">Transport Services</h2>
          <p className="mb-4">
            Indian School provides safe and reliable transport services for students. Our fleet of buses covers various
            routes across the city.
          </p>
          <ul className="space-y-4">
            <li className="flex items-start">
              <Bus className="mr-2 h-5 w-5 text-primary" />
              <span>Modern, well-maintained buses with GPS tracking</span>
            </li>
            <li className="flex items-start">
              <Clock className="mr-2 h-5 w-5 text-primary" />
              <span>Punctual pick-up and drop-off schedules</span>
            </li>
            <li className="flex items-start">
              <MapPin className="mr-2 h-5 w-5 text-primary" />
              <span>Extensive coverage of residential areas</span>
            </li>
          </ul>
        </section>
        <section>
          <h2 className="text-2xl font-bold mb-4">Contact Transport Department</h2>
          <p className="mb-4">
            For inquiries about bus routes, timings, or any other transport-related questions, please contact our
            transport department:
          </p>
          <div className="flex items-center mb-2">
            <Phone className="mr-2 h-5 w-5 text-primary" />
            <span>+91 98765 43210</span>
          </div>
          <p className="text-sm text-gray-600">Available from 8:00 AM to 4:00 PM on school days</p>
        </section>
      </div>
    </div>
  )
}

