import Image from "next/image"

const facilities = [
  {
    name: "Classrooms",
    description: "Modern, air-conditioned classrooms equipped with smart boards and projectors.",
    image: "/placeholder.svg?height=300&width=300&text=Classroom",
  },
  {
    name: "Library",
    description: "Extensive collection of books, journals, and digital resources.",
    image: "/placeholder.svg?height=300&width=300&text=Library",
  },
  {
    name: "Laboratories",
    description: "Well-equipped science, computer, and language labs.",
    image: "/placeholder.svg?height=300&width=300&text=Laboratory",
  },
  {
    name: "Sports Facilities",
    description: "Multi-purpose court, playground, and indoor sports area.",
    image: "/placeholder.svg?height=300&width=300&text=Sports+Facilities",
  },
  {
    name: "Auditorium",
    description: "State-of-the-art auditorium for events and performances.",
    image: "/placeholder.svg?height=300&width=300&text=Auditorium",
  },
  {
    name: "Cafeteria",
    description: "Spacious cafeteria serving nutritious meals.",
    image: "/placeholder.svg?height=300&width=300&text=Cafeteria",
  },
]

export default function FacilitiesPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-8 text-primary">Campus Facilities</h1>
      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        {facilities.map((facility, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="relative h-48">
              <Image src={facility.image || "/placeholder.svg"} alt={facility.name} fill className="object-cover" />
            </div>
            <div className="p-4">
              <h2 className="text-xl font-bold mb-2">{facility.name}</h2>
              <p className="text-gray-600">{facility.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

