import Link from "next/link"
import Image from "next/image"

export default function CampusPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-8 text-primary">Our Campus</h1>
      <div className="grid gap-8 md:grid-cols-2">
        <div>
          <p className="mb-4">
            Welcome to the Indian School campus, a place where learning comes alive. Our state-of-the-art facilities
            provide an ideal environment for academic, athletic, and artistic pursuits.
          </p>
          <ul className="list-disc list-inside mb-4">
            <li>Spacious classrooms equipped with modern technology</li>
            <li>Well-stocked library and computer labs</li>
            <li>Sports facilities including a multi-purpose court and playground</li>
            <li>Auditorium for cultural events and performances</li>
          </ul>
          <div className="space-y-4">
            <Link href="/campus/facilities" className="text-primary hover:underline block">
              Learn more about our facilities
            </Link>
            <Link href="/campus/transport" className="text-primary hover:underline block">
              School transport information
            </Link>
          </div>
        </div>
        <div className="relative aspect-video">
          <Image
            src="/placeholder.svg?height=400&width=600&text=Campus+Overview"
            alt="Campus Overview"
            fill
            className="object-cover rounded-lg"
          />
        </div>
      </div>
    </div>
  )
}

