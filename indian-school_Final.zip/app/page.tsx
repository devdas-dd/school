import Image from "next/image"
import Link from "next/link"
import { Award, BookOpen, Users, Lightbulb, Music, Trophy, ArrowRight } from "lucide-react"
import HeroSlider from "@/components/hero-slider"
import FeatureCard from "@/components/feature-card"
import TestimonialsSlider from "@/components/testimonials-slider"
import DynamicEvents from "@/components/DynamicEvents"

export default function Home() {
  return (
    <div>
      <HeroSlider />

      {/* About Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6 text-primary">Welcome to Indian School</h2>
              <p className="text-gray-600 mb-6">
                Indian School is a premier educational institution committed to providing quality education with a focus
                on holistic development. Established in 1985, we have been nurturing young minds and shaping futures for
                over three decades.
              </p>
              <p className="text-gray-600 mb-6">
                Our school follows the CBSE curriculum and offers a wide range of academic and extracurricular
                activities to ensure the all-round development of our students. With state-of-the-art facilities and
                experienced faculty, we strive to create an environment that fosters learning, creativity, and growth.
              </p>
              <Link
                href="/about"
                className="inline-flex items-center bg-primary text-white px-6 py-3 rounded-md hover:bg-primary/90 transition-colors"
              >
                Read More <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </div>
            <div className="relative h-[400px] rounded-lg overflow-hidden">
              <Image src="/placeholder.svg?height=400&width=600" alt="School Building" fill className="object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* Four Containers Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary">Why Choose Indian School</h2>
            <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
              We provide a nurturing environment where students can excel academically and develop essential life
              skills.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <FeatureCard
              title="Experienced Faculty"
              description="Our teachers are highly qualified and dedicated to providing the best education to our students."
              icon={<Users className="h-6 w-6" />}
              link="/about/why-choose-us"
            />
            <FeatureCard
              title="Academic Excellence"
              description="We follow the CBSE curriculum with additional focus on conceptual learning and practical applications."
              icon={<BookOpen className="h-6 w-6" />}
              link="/academics"
            />
            <FeatureCard
              title="Beyond Academics"
              description="We offer a wide range of extracurricular activities to ensure the holistic development of our students."
              icon={<Music className="h-6 w-6" />}
              link="/beyond-academics"
            />
            <FeatureCard
              title="Modern Facilities"
              description="Our campus is equipped with state-of-the-art facilities to enhance the learning experience."
              icon={<Lightbulb className="h-6 w-6" />}
              link="/campus/facilities"
            />
          </div>
        </div>
      </section>

      {/* Upcoming Events Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary">Upcoming Events</h2>
            <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
              Stay updated with the latest events and activities happening at Indian School.
            </p>
          </div>

          <DynamicEvents />

          <div className="text-center mt-10">
            <Link
              href="/news-events"
              className="inline-flex items-center bg-primary text-white px-6 py-3 rounded-md hover:bg-primary/90 transition-colors"
            >
              View All Events <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Achievements Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary">Our Achievements</h2>
            <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
              We take pride in the accomplishments of our students and the recognition our school has received.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 text-primary mb-4">
                <Trophy className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-2">Best CBSE School</h3>
              <p className="text-gray-600">
                Recognized as one of the top CBSE schools in the region for academic excellence.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 text-primary mb-4">
                <Award className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-2">100% Board Results</h3>
              <p className="text-gray-600">
                Consistently achieving 100% pass rate in CBSE board examinations with top ranks.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 text-primary mb-4">
                <Users className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-2">National Competitions</h3>
              <p className="text-gray-600">
                Our students have won numerous awards in national-level academic and sports competitions.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold">What Parents Say</h2>
            <p className="mt-4 max-w-2xl mx-auto opacity-80">
              Hear from the parents of our students about their experience with Indian School.
            </p>
          </div>
          <TestimonialsSlider />
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-primary text-center">School Gallery</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((index) => (
              <div key={index} className="relative aspect-square">
                <Image
                  src={`/placeholder.svg?height=300&width=300&text=Gallery+Image+${index}`}
                  alt={`Gallery Image ${index}`}
                  fill
                  className="object-cover rounded-lg"
                />
              </div>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link
              href="/gallery"
              className="inline-flex items-center bg-primary text-white px-6 py-3 rounded-md hover:bg-primary/90 transition-colors"
            >
              View Full Gallery
            </Link>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="bg-secondary/20 rounded-lg p-8 md:p-12 text-center">
            <h2 className="text-3xl font-bold text-primary mb-4">Ready to Join Indian School?</h2>
            <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
              Applications for the upcoming academic year are now open. Contact our admissions office or visit our
              campus to learn more.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link
                href="/admissions"
                className="bg-primary text-white px-6 py-3 rounded-md hover:bg-primary/90 transition-colors"
              >
                Apply Now
              </Link>
              <Link
                href="/contact"
                className="bg-white text-primary border border-primary px-6 py-3 rounded-md hover:bg-gray-50 transition-colors"
              >
                Contact Us
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

