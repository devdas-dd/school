import { NextResponse } from "next/server"

const testimonials = [
  {
    id: 1,
    text: "Indian School has provided my child with an excellent education and a nurturing environment. The teachers are dedicated and supportive, and the curriculum is comprehensive and challenging.",
    author: "Priya Sharma",
    role: "Parent",
  },
  {
    id: 2,
    text: "The holistic approach to education at Indian School has helped my son develop not just academically but also in sports and arts. The school truly focuses on all-round development.",
    author: "Rajesh Kumar",
    role: "Parent",
  },
  // Add more testimonials here
]

export async function GET() {
  return NextResponse.json(testimonials)
}

