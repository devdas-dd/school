import { NextResponse } from "next/server"

const newsItems = [
  {
    id: 1,
    title: "Annual Sports Day 2025",
    date: "March 15, 2025",
    image: "/placeholder.svg?height=200&width=300",
    excerpt:
      "Join us for a day of athletic competitions and team sports. Students from all grades will participate in various events.",
    slug: "annual-sports-day-2025",
  },
  {
    id: 2,
    title: "Science Exhibition",
    date: "April 5, 2025",
    image: "/placeholder.svg?height=200&width=300",
    excerpt:
      "Students will showcase their innovative science projects and experiments. Parents and community members are invited to attend.",
    slug: "science-exhibition-2025",
  },
  // Add more news items here
]

export async function GET() {
  return NextResponse.json(newsItems)
}

