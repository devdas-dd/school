import { NextResponse } from "next/server"

const upcomingEvents = [
  {
    id: 1,
    title: "Annual Sports Day",
    date: "March 15, 2025",
    time: "9:00 AM - 4:00 PM",
    venue: "School Sports Ground",
  },
  {
    id: 2,
    title: "Science Exhibition",
    date: "April 5, 2025",
    time: "10:00 AM - 3:00 PM",
    venue: "School Auditorium",
  },
  // Add more events here
]

export async function GET() {
  return NextResponse.json(upcomingEvents)
}

