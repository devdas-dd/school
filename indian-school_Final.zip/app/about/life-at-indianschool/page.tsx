import Image from "next/image"
import Link from "next/link"
import { Book, Music, Users, Award } from "lucide-react"

export default function LifeAtIndianSchoolPage() {
  return (
    <div>
      {/* Banner */}
      <div className="relative h-[300px] md:h-[400px]">
        <Image
          src="/placeholder.svg?height=400&width=1200"
          alt="Life at Indian School"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white">Life at Indian School</h1>
        </div>
      </div>

      {/* Introduction */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6 text-primary">A Day in the Life of an Indian School Student</h2>
            <p className="text-gray-600 mb-4">
              At Indian School, we believe in providing a holistic educational experience that goes beyond textbooks.
              Our students engage in a variety of activities that foster academic excellence, personal growth, and
              character development.
            </p>
          </div>
        </div>
      </section>

      {/* Daily Schedule */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-primary text-center">A Typical Day</h2>
          <div className="max-w-3xl mx-auto">
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="bg-primary text-white rounded-full p-3 mr-4">
                  <span className="text-sm font-bold">8:00</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold">Morning Assembly</h3>
                  <p className="text-gray-600">Start the day with prayers, news updates, and motivational speeches.</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-primary text-white rounded-full p-3 mr-4">
                  <span className="text-sm font-bold">8:30</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold">Classes Begin</h3>
                  <p className="text-gray-600">
                    Engaging lessons across various subjects with our experienced faculty.
                  </p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-primary text-white rounded-full p-3 mr-4">
                  <span className="text-sm font-bold">11:00</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold">Break Time</h3>
                  <p className="text-gray-600">Time for snacks, socializing, and a quick recharge.</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-primary text-white rounded-full p-3 mr-4">
                  <span className="text-sm font-bold">11:20</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold">More Classes</h3>
                  <p className="text-gray-600">Continue learning with interactive and practical sessions.</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-primary text-white rounded-full p-3 mr-4">
                  <span className="text-sm font-bold">13:30</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold">Lunch Break</h3>
                  <p className="text-gray-600">Enjoy a nutritious meal and relax with friends.</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-primary text-white rounded-full p-3 mr-4">
                  <span className="text-sm font-bold">14:15</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold">Extracurricular Activities</h3>
                  <p className="text-gray-600">Participate in sports, clubs, or additional academic support.</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-primary text-white rounded-full p-3 mr-4">
                  <span className="text-sm font-bold">15:30</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold">Day Ends</h3>
                  <p className="text-gray-600">
                    Reflect on the day's learning and head home or to after-school activities.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Key Aspects */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-primary text-center">Key Aspects of Student Life</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <Book className="h-12 w-12 mx-auto mb-4 text-primary" />
              <h3 className="text-xl font-bold mb-2">Academic Excellence</h3>
              <p className="text-gray-600">
                Rigorous curriculum and personalized attention to ensure every student reaches their full potential.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <Music className="h-12 w-12 mx-auto mb-4 text-primary" />
              <h3 className="text-xl font-bold mb-2">Arts and Culture</h3>
              <p className="text-gray-600">
                Opportunities to explore various forms of art, music, dance, and cultural activities.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <Users className="h-12 w-12 mx-auto mb-4 text-primary" />
              <h3 className="text-xl font-bold mb-2">Social Development</h3>
              <p className="text-gray-600">
                Foster friendships, teamwork, and leadership skills through various group activities and events.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <Award className="h-12 w-12 mx-auto mb-4 text-primary" />
              <h3 className="text-xl font-bold mb-2">Personal Growth</h3>
              <p className="text-gray-600">
                Emphasis on character development, values, and preparing students for future challenges.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Student Testimonials */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-primary text-center">What Our Students Say</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg shadow-md p-6">
              <p className="italic mb-4 text-gray-600">
                "Indian School has given me the confidence to pursue my dreams. The supportive teachers and diverse
                activities have helped me discover my true potential."
              </p>
              <div className="font-bold">Priya S., Class 12</div>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <p className="italic mb-4 text-gray-600">
                "I love the balance between academics and extracurricular activities here. It's helping me become a
                well-rounded individual."
              </p>
              <div className="font-bold">Rahul K., Class 10</div>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <p className="italic mb-4 text-gray-600">
                "The friendships I've made and the experiences I've had at Indian School will stay with me for life.
                It's more than just a school; it's a second home."
              </p>
              <div className="font-bold">Ananya M., Class 11</div>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6 text-primary">Experience Life at Indian School</h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Want to see firsthand what makes Indian School special? Schedule a visit or attend one of our open houses to
            experience the vibrant life on our campus.
          </p>
          <Link
            href="/contact"
            className="inline-flex items-center bg-primary text-white px-6 py-3 rounded-md hover:bg-primary/90 transition-colors"
          >
            Schedule a Visit
          </Link>
        </div>
      </section>
    </div>
  )
}

