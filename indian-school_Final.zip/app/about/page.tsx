import Image from "next/image"
import Link from "next/link"
import { FileText } from "lucide-react"

export default function AboutPage() {
  return (
    <div>
      {/* Banner */}
      <div className="relative h-[300px] md:h-[400px]">
        <Image src="/placeholder.svg?height=400&width=1200" alt="About Us" fill className="object-cover" priority />
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white">About Us</h1>
        </div>
      </div>

      {/* Introduction */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6 text-primary">Our History</h2>
              <p className="text-gray-600 mb-4">
                Indian School was established in 1985 with a vision to provide quality education that nurtures young
                minds and prepares them for the challenges of the future. What started as a small institution with just
                a few classrooms has now grown into one of the leading schools in the region.
              </p>
              <p className="text-gray-600 mb-4">
                Over the years, we have expanded our facilities, enhanced our curriculum, and built a strong reputation
                for academic excellence and holistic development. Our alumni have gone on to achieve success in various
                fields, both in India and abroad.
              </p>
              <p className="text-gray-600">
                Today, Indian School stands as a testament to our commitment to educational excellence and our
                dedication to shaping the future of our nation through quality education.
              </p>
            </div>
            <div className="relative h-[400px] rounded-lg overflow-hidden">
              <Image src="/placeholder.svg?height=400&width=600" alt="School History" fill className="object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* Mission and Vision */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="bg-white p-8 rounded-lg shadow-md">
              <h2 className="text-2xl font-bold mb-4 text-primary">Our Mission</h2>
              <p className="text-gray-600">
                To provide a nurturing and stimulating environment where students can develop their intellectual,
                physical, emotional, and social potential to the fullest. We aim to equip our students with the
                knowledge, skills, and values necessary to become responsible global citizens who contribute positively
                to society.
              </p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-md">
              <h2 className="text-2xl font-bold mb-4 text-primary">Our Vision</h2>
              <p className="text-gray-600">
                To be a center of excellence in education that inspires and empowers students to become lifelong
                learners, critical thinkers, and compassionate individuals who are prepared to meet the challenges of a
                rapidly changing world with confidence and integrity.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Leadership */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-primary text-center">Our Leadership</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="relative h-[300px]">
                <Image src="/placeholder.svg?height=300&width=300" alt="Principal" fill className="object-cover" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Dr. Rajesh Sharma</h3>
                <p className="text-primary font-medium mb-4">Principal</p>
                <p className="text-gray-600">
                  Dr. Sharma has over 25 years of experience in education and holds a Ph.D. in Educational Leadership.
                  Under his guidance, Indian School has achieved numerous milestones in academic excellence.
                </p>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="relative h-[300px]">
                <Image src="/placeholder.svg?height=300&width=300" alt="Vice Principal" fill className="object-cover" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Mrs. Priya Patel</h3>
                <p className="text-primary font-medium mb-4">Vice Principal</p>
                <p className="text-gray-600">
                  Mrs. Patel specializes in curriculum development and student welfare. She has been instrumental in
                  implementing innovative teaching methodologies at Indian School.
                </p>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="relative h-[300px]">
                <Image
                  src="/placeholder.svg?height=300&width=300"
                  alt="Administrative Head"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Mr. Anil Kumar</h3>
                <p className="text-primary font-medium mb-4">Administrative Head</p>
                <p className="text-gray-600">
                  Mr. Kumar oversees the administrative functions of the school, ensuring smooth operations and
                  efficient management of resources.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Awards & Achievements */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-primary text-center">Awards & Achievements</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md flex items-start">
              <div className="bg-primary/10 p-3 rounded-full mr-4">
                <Image src="/placeholder.svg?height=50&width=50" alt="Award" width={50} height={50} />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Best CBSE School Award</h3>
                <p className="text-gray-600">
                  Recognized as one of the top CBSE schools in the region for academic excellence and infrastructure.
                </p>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md flex items-start">
              <div className="bg-primary/10 p-3 rounded-full mr-4">
                <Image src="/placeholder.svg?height=50&width=50" alt="Award" width={50} height={50} />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Excellence in Sports</h3>
                <p className="text-gray-600">
                  Awarded for outstanding performance in inter-school sports competitions at the state level.
                </p>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md flex items-start">
              <div className="bg-primary/10 p-3 rounded-full mr-4">
                <Image src="/placeholder.svg?height=50&width=50" alt="Award" width={50} height={50} />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Green School Award</h3>
                <p className="text-gray-600">
                  Recognized for our eco-friendly initiatives and environmental awareness programs.
                </p>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md flex items-start">
              <div className="bg-primary/10 p-3 rounded-full mr-4">
                <Image src="/placeholder.svg?height=50&width=50" alt="Award" width={50} height={50} />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Innovation in Education</h3>
                <p className="text-gray-600">
                  Awarded for implementing innovative teaching methodologies and technology integration in education.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mandatory Disclosure */}
      <section className="py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6 text-primary">Mandatory Disclosure</h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            In compliance with CBSE regulations, we provide complete transparency regarding our school's infrastructure,
            faculty, and other important information.
          </p>
          <Link
            href="/about/mandatory-disclosure"
            className="inline-flex items-center bg-primary text-white px-6 py-3 rounded-md hover:bg-primary/90 transition-colors"
          >
            <FileText className="mr-2 h-5 w-5" />
            View Mandatory Disclosure
          </Link>
        </div>
      </section>
    </div>
  )
}

