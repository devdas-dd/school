import Image from "next/image"
import { CheckCircle, Users, BookOpen, Lightbulb, Award, Globe } from "lucide-react"

export default function WhyChooseUsPage() {
  return (
    <div>
      {/* Banner */}
      <div className="relative h-[300px] md:h-[400px]">
        <Image
          src="/placeholder.svg?height=400&width=1200"
          alt="Why Choose Us"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white">Why Choose Us</h1>
        </div>
      </div>

      {/* Introduction */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6 text-primary">What Sets Us Apart</h2>
            <p className="text-gray-600 mb-4">
              At Indian School, we are committed to providing a nurturing environment where students can excel
              academically and develop essential life skills. Our unique approach to education focuses on the holistic
              development of each child, preparing them for success in a rapidly changing world.
            </p>
            <p className="text-gray-600">
              Here are some key reasons why parents and students choose Indian School for their educational journey.
            </p>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md flex items-start">
              <div className="bg-primary/10 p-3 rounded-full mr-4 text-primary">
                <Users className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Experienced Faculty</h3>
                <p className="text-gray-600">
                  Our teachers are highly qualified and experienced professionals who are passionate about education.
                  They employ innovative teaching methodologies to make learning engaging and effective.
                </p>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md flex items-start">
              <div className="bg-primary/10 p-3 rounded-full mr-4 text-primary">
                <BookOpen className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Comprehensive Curriculum</h3>
                <p className="text-gray-600">
                  We follow the CBSE curriculum with additional focus on conceptual learning, critical thinking, and
                  practical applications. Our curriculum is designed to develop both academic knowledge and essential
                  life skills.
                </p>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md flex items-start">
              <div className="bg-primary/10 p-3 rounded-full mr-4 text-primary">
                <Lightbulb className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">State-of-the-Art Facilities</h3>
                <p className="text-gray-600">
                  Our campus is equipped with modern facilities including well-equipped laboratories, a comprehensive
                  library, smart classrooms, sports facilities, and more to enhance the learning experience.
                </p>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md flex items-start">
              <div className="bg-primary/10 p-3 rounded-full mr-4 text-primary">
                <Award className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Focus on Holistic Development</h3>
                <p className="text-gray-600">
                  We believe in the all-round development of our students. Along with academics, we emphasize sports,
                  arts, music, dance, and other extracurricular activities to nurture various talents.
                </p>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md flex items-start">
              <div className="bg-primary/10 p-3 rounded-full mr-4 text-primary">
                <Globe className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Global Perspective</h3>
                <p className="text-gray-600">
                  We prepare our students to be global citizens by exposing them to diverse cultures, international
                  educational practices, and global issues, fostering a broader worldview.
                </p>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md flex items-start">
              <div className="bg-primary/10 p-3 rounded-full mr-4 text-primary">
                <CheckCircle className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Value-Based Education</h3>
                <p className="text-gray-600">
                  We instill strong moral values and ethics in our students, helping them develop into responsible,
                  compassionate, and principled individuals who contribute positively to society.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-primary text-center">What Our Community Says</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="relative h-12 w-12 rounded-full overflow-hidden mr-4">
                  <Image src="/placeholder.svg?height=50&width=50" alt="Parent" fill className="object-cover" />
                </div>
                <div>
                  <h3 className="font-bold">Priya Sharma</h3>
                  <p className="text-sm text-gray-500">Parent</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "Indian School has provided my child with an excellent education and a nurturing environment. The
                teachers are dedicated and supportive, and the curriculum is comprehensive and challenging."
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="relative h-12 w-12 rounded-full overflow-hidden mr-4">
                  <Image src="/placeholder.svg?height=50&width=50" alt="Alumni" fill className="object-cover" />
                </div>
                <div>
                  <h3 className="font-bold">Rahul Verma</h3>
                  <p className="text-sm text-gray-500">Alumni</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "My years at Indian School were transformative. The school not only prepared me academically but also
                instilled values and skills that have been invaluable in my career and personal life."
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="relative h-12 w-12 rounded-full overflow-hidden mr-4">
                  <Image src="/placeholder.svg?height=50&width=50" alt="Student" fill className="object-cover" />
                </div>
                <div>
                  <h3 className="font-bold">Ananya Singh</h3>
                  <p className="text-sm text-gray-500">Student</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "I love being a student at Indian School. The teachers make learning fun and interesting, and there are
                so many opportunities to explore different activities and develop new skills."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Statistics */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-center">Our Impact in Numbers</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-5xl font-bold mb-2">35+</div>
              <p className="text-xl">Years of Excellence</p>
            </div>

            <div className="text-center">
              <div className="text-5xl font-bold mb-2">100+</div>
              <p className="text-xl">Experienced Faculty</p>
            </div>

            <div className="text-center">
              <div className="text-5xl font-bold mb-2">5000+</div>
              <p className="text-xl">Alumni Network</p>
            </div>

            <div className="text-center">
              <div className="text-5xl font-bold mb-2">98%</div>
              <p className="text-xl">Board Exam Success Rate</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

