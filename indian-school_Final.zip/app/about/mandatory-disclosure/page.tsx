import Link from "next/link"
import { FileText, Download, ExternalLink } from "lucide-react"

export default function MandatoryDisclosurePage() {
  return (
    <div>
      {/* Banner */}
      <div className="bg-primary py-16 md:py-24">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground mb-4">Mandatory Disclosure</h1>
          <p className="text-primary-foreground/80 max-w-2xl mx-auto">
            In compliance with CBSE regulations, we provide complete transparency regarding our school's infrastructure,
            faculty, and other important information.
          </p>
        </div>
      </div>

      {/* Introduction */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-8">
              <div className="flex">
                <div className="flex-shrink-0">
                  <FileText className="h-5 w-5 text-yellow-400" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-yellow-700">
                    This page contains mandatory information as required by the Central Board of Secondary Education
                    (CBSE) for all affiliated schools.
                  </p>
                </div>
              </div>
            </div>

            <p className="text-gray-600 mb-6">
              Indian School is committed to transparency and accountability. In accordance with the CBSE guidelines, we
              provide the following information for public access. This disclosure is updated regularly to ensure
              accuracy and compliance with regulatory requirements.
            </p>

            <div className="mb-8 text-center">
              <Link
                href="#"
                className="inline-flex items-center bg-primary text-white px-6 py-3 rounded-md hover:bg-primary/90 transition-colors"
              >
                <Download className="mr-2 h-5 w-5" />
                Download Complete Mandatory Disclosure (PDF)
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* General Information */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold mb-6 text-primary">A. General Information</h2>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <tbody className="divide-y divide-gray-200">
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      Name of the School
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Indian School</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      Affiliation Number
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">XXXXXXXX</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      School Code
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">XXXXX</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      Complete Address
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      123 Education Street, New Delhi, India - 110001
                    </td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      Principal Name & Qualification
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      Dr. Rajesh Sharma, Ph.D. in Educational Leadership
                    </td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      School Email
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">info@indianschool.edu</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      Contact Details
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">+91 123 456 7890</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      {/* Details of Infrastructure */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold mb-6 text-primary">B. Details of Infrastructure</h2>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <tbody className="divide-y divide-gray-200">
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      Total Campus Area
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">5 Acres</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      Number of Classrooms
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">50</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      Laboratories
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      Physics, Chemistry, Biology, Computer Science (2)
                    </td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      Library
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Yes, with 15,000+ books</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      Sports Facilities
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      Playground, Basketball Court, Indoor Sports Hall
                    </td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      Swimming Pool
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Yes</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      Auditorium
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Yes, capacity of 500 people</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      {/* Staff Details */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold mb-6 text-primary">C. Staff Details</h2>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <tbody className="divide-y divide-gray-200">
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      Number of Teaching Staff
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">75</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      Number of Non-Teaching Staff
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">25</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      Pupil-Teacher Ratio
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">20:1</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      Details of Special Educators
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      3 Special Educators with relevant qualifications
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      {/* Academic Information */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold mb-6 text-primary">D. Academic Information</h2>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <tbody className="divide-y divide-gray-200">
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      Classes From
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Pre-Primary to XII</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      School Timings
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">8:00 AM to 2:30 PM</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      Board Examination Results
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <Link href="#" className="text-primary hover:underline flex items-center">
                        View Results <ExternalLink className="ml-1 h-4 w-4" />
                      </Link>
                    </td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap bg-gray-50 text-sm font-medium text-gray-900">
                      Academic Calendar
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <Link href="#" className="text-primary hover:underline flex items-center">
                        Download Calendar <Download className="ml-1 h-4 w-4" />
                      </Link>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      {/* Fee Structure */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold mb-6 text-primary">E. Fee Structure</h2>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="px-6 py-4">
                <p className="text-gray-600 mb-4">
                  The fee structure for the academic year 2024-2025 is available for download. The fee structure is
                  approved by the School Managing Committee and is in compliance with the guidelines issued by the CBSE
                  and the Department of Education.
                </p>
                <Link href="#" className="inline-flex items-center text-primary hover:text-primary/80 font-medium">
                  Download Fee Structure <Download className="ml-1 h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Admission Information */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold mb-6 text-primary">F. Admission Information</h2>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="px-6 py-4">
                <p className="text-gray-600 mb-4">
                  Admission to Indian School is based on merit and is open to all, regardless of religion, caste, or
                  gender. The admission process is transparent and follows the guidelines issued by the CBSE and the
                  Department of Education.
                </p>
                <Link
                  href="/admissions"
                  className="inline-flex items-center text-primary hover:text-primary/80 font-medium"
                >
                  View Admission Details <ExternalLink className="ml-1 h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Safety Measures */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold mb-6 text-primary">G. Safety Measures</h2>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="px-6 py-4">
                <ul className="list-disc list-inside text-gray-600 space-y-2">
                  <li>Fire safety equipment installed throughout the campus</li>
                  <li>Regular fire and evacuation drills conducted</li>
                  <li>CCTV cameras installed for security</li>
                  <li>Security personnel present at all times</li>
                  <li>First aid facilities available</li>
                  <li>School transport follows all safety guidelines</li>
                  <li>Child Protection Policy in place</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact for Inquiries */}
      <section className="py-8 mb-8">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold mb-6 text-primary">H. Contact for Inquiries</h2>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="px-6 py-4">
                <p className="text-gray-600 mb-4">
                  For any inquiries regarding the mandatory disclosure or other information about the school, please
                  contact:
                </p>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <span className="font-medium w-24">Email:</span>
                    <span>info@indianschool.edu</span>
                  </div>
                  <div className="flex items-center">
                    <span className="font-medium w-24">Phone:</span>
                    <span>+91 123 456 7890</span>
                  </div>
                  <div className="flex items-center">
                    <span className="font-medium w-24">Address:</span>
                    <span>123 Education Street, New Delhi, India - 110001</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

