"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { User, Users, GraduationCap, Lock, Mail } from "lucide-react"

type UserType = "staff" | "parent" | "student"

export default function LoginPage() {
  const [userType, setUserType] = useState<UserType>("staff")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setIsLoading(true)

    // Simulate login process
    try {
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // In a real application, you would make an API call to authenticate
      // For demo purposes, we're just simulating the process

      // Reset form and show success (in a real app, you would redirect)
      setIsLoading(false)
      alert(`${userType} login successful!`)
    } catch (err) {
      setIsLoading(false)
      setError("Invalid email or password. Please try again.")
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-md mx-auto bg-white rounded-lg shadow-md overflow-hidden">
          <div className="bg-primary p-6 text-center">
            <Link href="/" className="inline-block">
              <Image
                src="/placeholder.svg?height=60&width=60"
                alt="Indian School Logo"
                width={60}
                height={60}
                className="mx-auto"
              />
            </Link>
            <h1 className="text-2xl font-bold text-primary-foreground mt-4">Login to Indian School</h1>
          </div>

          <div className="p-6">
            {/* User Type Selection */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              <button
                type="button"
                onClick={() => setUserType("staff")}
                className={`flex flex-col items-center justify-center p-4 rounded-lg border ${
                  userType === "staff"
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-gray-200 hover:bg-gray-50"
                }`}
              >
                <User className="h-6 w-6 mb-2" />
                <span className="text-sm font-medium">Staff</span>
              </button>

              <button
                type="button"
                onClick={() => setUserType("parent")}
                className={`flex flex-col items-center justify-center p-4 rounded-lg border ${
                  userType === "parent"
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-gray-200 hover:bg-gray-50"
                }`}
              >
                <Users className="h-6 w-6 mb-2" />
                <span className="text-sm font-medium">Parent</span>
              </button>

              <button
                type="button"
                onClick={() => setUserType("student")}
                className={`flex flex-col items-center justify-center p-4 rounded-lg border ${
                  userType === "student"
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-gray-200 hover:bg-gray-50"
                }`}
              >
                <GraduationCap className="h-6 w-6 mb-2" />
                <span className="text-sm font-medium">Student</span>
              </button>
            </div>

            {/* Login Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && <div className="bg-red-50 text-red-500 p-3 rounded-md text-sm">{error}</div>}

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                    placeholder={`${userType === "staff" ? "Staff" : userType === "parent" ? "Parent" : "Student"} Email`}
                  />
                </div>
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                  Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    id="password"
                    name="password"
                    type="password"
                    autoComplete="current-password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                    placeholder="Password"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <input
                    id="remember-me"
                    name="remember-me"
                    type="checkbox"
                    className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                  />
                  <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-700">
                    Remember me
                  </label>
                </div>

                <div className="text-sm">
                  <Link href="/forgot-password" className="text-primary hover:text-primary/80">
                    Forgot your password?
                  </Link>
                </div>
              </div>

              <div>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:opacity-50"
                >
                  {isLoading ? "Signing in..." : "Sign in"}
                </button>
              </div>
            </form>

            {userType === "parent" && (
              <div className="mt-6 text-center">
                <p className="text-sm text-gray-600">
                  New parent?{" "}
                  <Link href="/register" className="text-primary hover:text-primary/80 font-medium">
                    Register here
                  </Link>
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

