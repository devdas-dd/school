import { Palette, Music, Trophy, Globe, Book, Cpu, Camera, Mic } from "lucide-react"

const activities = [
  { name: "Art Club", icon: Palette, description: "Explore various art forms and techniques." },
  { name: "Music Ensemble", icon: Music, description: "Join our school band or choir." },
  { name: "Sports Teams", icon: Trophy, description: "Participate in competitive sports at various levels." },
  { name: "Model United Nations", icon: Globe, description: "Develop diplomacy and public speaking skills." },
  { name: "Book Club", icon: Book, description: "Share your love for literature with fellow bookworms." },
  { name: "Robotics Club", icon: Cpu, description: "Design and build robots for competitions." },
  { name: "Photography Club", icon: Camera, description: "Learn the art of capturing moments through a lens." },
  { name: "Debate Society", icon: Mic, description: "Hone your argumentation and critical thinking skills." },
]

export default function ExtracurricularPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-8 text-primary">Extracurricular Activities</h1>
      <p className="mb-8 text-lg">
        Our diverse range of extracurricular activities allows students to explore their passions, develop new skills,
        and create lasting friendships.
      </p>
      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        {activities.map((activity, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md p-6">
            <activity.icon className="h-12 w-12 text-primary mb-4" />
            <h2 className="text-xl font-bold mb-2">{activity.name}</h2>
            <p className="text-gray-600">{activity.description}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

