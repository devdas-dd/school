import Link from "next/link"
import { Palette, Music, Trophy, Globe } from "lucide-react"

const activities = [
  { name: "Arts & Crafts", icon: Palette, description: "Explore various artistic mediums and develop creativity." },
  { name: "Music & Dance", icon: Music, description: "Learn classical and contemporary forms of music and dance." },
  { name: "Sports", icon: Trophy, description: "Participate in a wide range of individual and team sports." },
  {
    name: "Cultural Exchange",
    icon: Globe,
    description: "Engage in programs that promote global awareness and cultural understanding.",
  },
]

export default function BeyondAcademicsPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-8 text-primary">Beyond Academics</h1>
      <p className="mb-8 text-lg">
        At Indian School, we believe in nurturing well-rounded individuals. Our beyond academics programs offer students
        opportunities to explore their interests, develop new skills, and grow personally.
      </p>
      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
        {activities.map((activity, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md p-6">
            <activity.icon className="h-12 w-12 text-primary mb-4" />
            <h2 className="text-xl font-bold mb-2">{activity.name}</h2>
            <p className="text-gray-600 mb-4">{activity.description}</p>
          </div>
        ))}
      </div>
      <div className="mt-12 text-center">
        <Link
          href="/beyond-academics/extra-curricular"
          className="inline-flex items-center bg-primary text-white px-6 py-3 rounded-md hover:bg-primary/90 transition-colors"
        >
          Explore Extracurricular Activities
        </Link>
      </div>
    </div>
  )
}

