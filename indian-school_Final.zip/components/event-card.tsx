import Link from "next/link"
import { Calendar } from "lucide-react"

interface EventCardProps {
  title: string
  date: string
  description: string
  link: string
}

export default function EventCard({ title, date, description, link }: EventCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 transition-all hover:shadow-lg">
      <div className="flex items-center text-primary mb-2">
        <Calendar className="h-5 w-5 mr-2" />
        <span className="text-sm font-medium">{date}</span>
      </div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-gray-600 mb-4 line-clamp-2">{description}</p>
      <Link href={link} className="text-primary hover:text-primary/80 font-medium">
        Read More
      </Link>
    </div>
  )
}

