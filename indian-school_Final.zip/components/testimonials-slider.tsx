"use client"

import { useState, useEffect, useCallback } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"

interface Testimonial {
  id: number
  text: string
  author: string
  role: string
}

export default function TestimonialsSlider() {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([])
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isAnimating, setIsAnimating] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchTestimonials() {
      try {
        const res = await fetch("/api/testimonials")
        if (!res.ok) {
          throw new Error("Failed to fetch testimonials")
        }
        const data = await res.json()
        setTestimonials(data)
      } catch (err) {
        setError("Failed to load testimonials. Please try again later.")
      } finally {
        setIsLoading(false)
      }
    }
    fetchTestimonials()
  }, [])

  const nextSlide = useCallback(() => {
    if (isAnimating || testimonials.length === 0) return
    setIsAnimating(true)
    setCurrentSlide((prev) => (prev === testimonials.length - 1 ? 0 : prev + 1))
    setTimeout(() => setIsAnimating(false), 500)
  }, [isAnimating, testimonials.length])

  const prevSlide = useCallback(() => {
    if (isAnimating || testimonials.length === 0) return
    setIsAnimating(true)
    setCurrentSlide((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1))
    setTimeout(() => setIsAnimating(false), 500)
  }, [isAnimating, testimonials.length])

  useEffect(() => {
    const interval = setInterval(() => {
      nextSlide()
    }, 5000)
    return () => clearInterval(interval)
  }, [nextSlide])

  if (isLoading) {
    return <div className="text-center">Loading testimonials...</div>
  }

  if (error) {
    return <div className="text-center text-red-500">{error}</div>
  }

  if (testimonials.length === 0) {
    return null
  }

  return (
    <div className="relative max-w-4xl mx-auto">
      <div className="overflow-hidden">
        <div
          className="flex transition-transform duration-500 ease-in-out"
          style={{ transform: `translateX(-${currentSlide * 100}%)` }}
        >
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="min-w-full px-4">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-8 text-center">
                <p className="italic mb-6 text-lg">"{testimonial.text}"</p>
                <div className="font-semibold text-lg">{testimonial.author}</div>
                <div className="text-primary-foreground/70">{testimonial.role}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <button
        onClick={prevSlide}
        className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 bg-black/30 hover:bg-black/50 text-white p-2 rounded-full"
        aria-label="Previous testimonial"
      >
        <ChevronLeft className="h-6 w-6" />
      </button>

      <button
        onClick={nextSlide}
        className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 bg-black/30 hover:bg-black/50 text-white p-2 rounded-full"
        aria-label="Next testimonial"
      >
        <ChevronRight className="h-6 w-6" />
      </button>

      <div className="flex justify-center mt-6 space-x-2">
        {testimonials.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full ${currentSlide === index ? "bg-white" : "bg-white/50"}`}
            aria-label={`Go to testimonial ${index + 1}`}
          />
        ))}
      </div>
    </div>
  )
}

