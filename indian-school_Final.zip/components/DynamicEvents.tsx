"use client"

import { useState, useEffect } from "react"
import EventCard from "@/components/event-card"

interface Event {
  id: number
  title: string
  date: string
  time: string
  venue: string
}

export default function DynamicEvents() {
  const [events, setEvents] = useState<Event[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchEvents() {
      try {
        const res = await fetch("/api/events")
        if (!res.ok) {
          throw new Error("Failed to fetch events")
        }
        const data = await res.json()
        setEvents(data)
      } catch (err) {
        setError("Failed to load events. Please try again later.")
      } finally {
        setIsLoading(false)
      }
    }

    fetchEvents()
  }, [])

  if (isLoading) {
    return <div className="text-center">Loading events...</div>
  }

  if (error) {
    return <div className="text-center text-red-500">{error}</div>
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {events.slice(0, 3).map((event) => (
        <EventCard
          key={event.id}
          title={event.title}
          date={event.date}
          description={`${event.time} at ${event.venue}`}
          link="/news-events"
        />
      ))}
    </div>
  )
}

