import Link from "next/link"
import { Phone, Mail, User } from "lucide-react"

export default function TopMenu() {
  return (
    <div className="bg-primary text-primary-foreground py-2">
      <div className="container mx-auto px-4 flex flex-col sm:flex-row justify-between items-center">
        <div className="flex flex-col sm:flex-row items-center space-y-2 sm:space-y-0 sm:space-x-4 mb-2 sm:mb-0">
          <div className="flex items-center text-sm">
            <Phone className="h-4 w-4 mr-1" />
            <span>+91 123 456 7890</span>
          </div>
          <div className="flex items-center text-sm">
            <Mail className="h-4 w-4 mr-1" />
            <span>info@indianschool.edu</span>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <Link href="/admissions" className="text-sm hover:underline">
            Admissions
          </Link>
          <Link href="/contact" className="text-sm hover:underline">
            Contact
          </Link>
          <Link href="/login" className="flex items-center text-sm hover:underline">
            <User className="h-4 w-4 mr-1" />
            <span>Login</span>
          </Link>
        </div>
      </div>
    </div>
  )
}

