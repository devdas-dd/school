import Link from "next/link"
import Image from "next/image"
import { MapPin, Phone, Mail, Facebook, Twitter, Instagram, Youtube } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container mx-auto py-12 px-4 sm:px-6 lg:py-16 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 mr-2 mt-0.5" />
                <span>123 Education Street, New Delhi, India - 110001</span>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 mr-2" />
                <span>+91 123 456 7890</span>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 mr-2" />
                <span>info@indianschool.edu</span>
              </li>
            </ul>
            <div className="flex space-x-4 mt-4">
              <Link href="#" className="hover:text-secondary">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link href="#" className="hover:text-secondary">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </Link>
              <Link href="#" className="hover:text-secondary">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link href="#" className="hover:text-secondary">
                <Youtube className="h-5 w-5" />
                <span className="sr-only">YouTube</span>
              </Link>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="hover:text-secondary">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/academics" className="hover:text-secondary">
                  Academics
                </Link>
              </li>
              <li>
                <Link href="/admissions" className="hover:text-secondary">
                  Admissions
                </Link>
              </li>
              <li>
                <Link href="/campus" className="hover:text-secondary">
                  Campus
                </Link>
              </li>
              <li>
                <Link href="/beyond-academics" className="hover:text-secondary">
                  Beyond Academics
                </Link>
              </li>
              <li>
                <Link href="/news-events" className="hover:text-secondary">
                  News & Events
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-secondary">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Useful Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="https://www.cbse.gov.in/" target="_blank" className="hover:text-secondary">
                  CBSE
                </Link>
              </li>
              <li>
                <Link href="https://ncert.nic.in/" target="_blank" className="hover:text-secondary">
                  NCERT
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-secondary">
                  Mandatory Disclosure
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-secondary">
                  Career
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-secondary">
                  Alumni
                </Link>
              </li>
            </ul>
          </div>

          <div className="flex flex-col items-center">
            <Image
              src="/placeholder.svg?height=80&width=80"
              alt="Indian School Logo"
              width={80}
              height={80}
              className="mb-4"
            />
            <p className="text-center text-sm">
              Indian School is committed to providing quality education with a focus on holistic development and
              academic excellence.
            </p>
          </div>
        </div>

        <div className="mt-12 border-t border-primary-foreground/20 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm">&copy; {new Date().getFullYear()} Indian School. All rights reserved.</p>
          <div className="mt-4 md:mt-0 flex space-x-6">
            <Link href="/privacy-policy" className="text-sm hover:text-secondary">
              Privacy Policy
            </Link>
            <Link href="/terms-of-service" className="text-sm hover:text-secondary">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}

